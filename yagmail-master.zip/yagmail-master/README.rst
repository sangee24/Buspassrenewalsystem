The simple goal here is to make it as simple and painless as possible to send an email.

For documentation and examples, go to https://github.com/kootenpv/yagmail
