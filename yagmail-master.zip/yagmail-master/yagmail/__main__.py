from .yagmail import main

main()
