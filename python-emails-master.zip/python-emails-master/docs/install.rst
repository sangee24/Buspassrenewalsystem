
Install
-------

Install from pypi:

.. code-block:: bash

    $ [sudo] pip install emails

Install on Ubuntu from PPA:

.. code-block:: bash

    $ [sudo] add-apt-repository ppa:lavrme/python-emails-ppa
    $ [sudo] apt-get update
    $ [sudo] apt-get install python-emails
