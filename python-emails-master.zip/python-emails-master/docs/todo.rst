
TODO
----

- Documentation
- Increase test coverage
- Feature: load message from rfc2822
- Feature: export message to directory or zipfile
- Distribution: deb package (`debianization example <https://github.com/lavr/python-emails-debian/>`_)
- Distribution: rpm package
- Other: Flask extension
- Feature: ESP integration - Amazon SES, SendGrid, ...
