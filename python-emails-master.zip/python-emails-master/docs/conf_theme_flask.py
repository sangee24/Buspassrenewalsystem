# -*- coding: utf-8 -*-

html_theme = 'flask_small'
html_theme_options = {
}