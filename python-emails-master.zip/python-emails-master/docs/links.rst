
See also
--------

There are plenty other python email-around libraries that may fit your needs:

 - `premailer <https://github.com/peterbe/premailer>`_
 - `flask-mail <https://github.com/mattupstate/flask-mail>`_
 - `pyzmail <http://www.magiksys.net/pyzmail/>`_
 - `marrow.mailer <https://github.com/marrow/marrow.mailer>`_
