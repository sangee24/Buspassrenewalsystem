Authors
```````

python-emails is maintained by:

- `@lavr <https://github.com/lavr>`_

With inputs and contributions from (in chronological order):

- `@smihai <https://github.com/smihai>`_
- `@Daviey <https://github.com/Daviey>`_
- `@positiveviking <https://github.com/positiveviking>`_

See `all Github contributors <https://github.com/lavr/python-emails/graphs/contributors>`_

