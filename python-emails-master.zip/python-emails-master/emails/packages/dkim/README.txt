This is dkimpy 0.5.3 with @lavr's patch for caching parsed key.

Fork of https://code.launchpad.net/~diane-trout/dkimpy/python3