# encoding: utf-8
import warnings
warnings.warn("emails.django_ module moved to emails.django", DeprecationWarning)

from .django import *